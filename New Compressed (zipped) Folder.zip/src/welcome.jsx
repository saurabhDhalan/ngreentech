import React from 'react';
import Login from './login/login';
import Registration from './Pages/registration';


class Welcome extends React.Component {
    render() {
        return (
            <div>
                <Login></Login>
                <Registration></Registration>
            </div>
        );
    }
}

export default Welcome;