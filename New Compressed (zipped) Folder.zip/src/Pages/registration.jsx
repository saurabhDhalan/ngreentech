import React from 'react';

class Registration extends React.Component {
    render() {
        return (
            <div>
                <h1 style={{color: "red"}}>This is Registration Page.....</h1>
            </div>
        );
    }
}

export default Registration;